import json
import os
import random
import timeit

import pandas as pd
import redis


# Import BPlusTree implementation
class BPlusTree:
    def __init__(self, max_degree):
        self.root = BPlusTreeNode(max_degree)

    def insert(self, key, value):
        self.root.insert(key, value)

    def search(self, key):
        return self.root.search(key)

    def print_tree(self):
        self.root.print_node()

class BPlusTreeNode:
    def __init__(self, max_degree, is_leaf=True):
        self.keys = []
        self.values = []
        self.is_leaf = is_leaf
        self.children = []
        self.max_degree = max_degree

    def insert(self, key, value):
        if self.is_leaf:
            self.insert_leaf(key, value)
        else:
            index = self.find_child_index(key)
            self.children[index].insert(key, value)

    def insert_leaf(self, key, value):
        index = self.find_insert_index(key)
        self.keys.insert(index, key)
        self.values.insert(index, value)

        if len(self.keys) > self.max_degree - 1:
            self.split_leaf()

    def split_leaf(self):
        mid = len(self.keys) // 2
        right_node = BPlusTreeNode(self.max_degree, is_leaf=True)
        right_node.keys = self.keys[mid:]
        right_node.values = self.values[mid:]
        self.keys = self.keys[:mid]
        self.values = self.values[:mid]
        self.children.append(right_node)

    def find_child_index(self, key):
        for i, k in enumerate(self.keys):
            if key < k:
                return i
        return len(self.keys)

    def find_insert_index(self, key):
        for i, k in enumerate(self.keys):
            if key <= k:
                return i
        return len(self.keys)

    def search(self, key):
        if self.is_leaf:
            index = self.find_key_index(key)
            if index != -1:
                return self.values[index]
            return None
        else:
            index = self.find_child_index(key)
            if index < len(self.keys) and key == self.keys[index]:
                return self.children[index + 1].search(key)
            else:
                return self.children[index].search(key)

    def find_key_index(self, key):
        for i, k in enumerate(self.keys):
            if key == k:
                return i
        return -1

    def print_node(self, level=0):
        if level == 0:
            print("Root:", self.keys)
        else:
            print("Level", level, ":", self.keys)
        if not self.is_leaf:
            for child in self.children:
                child.print_node(level + 1)

# Setup Redis connection
redis_host = 'localhost'
redis_port = 6379
r = redis.Redis(host=redis_host, port=redis_port, db=0, decode_responses=False)

# Paths to TPC-H data files
base_path = './tpch-dbgen/'  # Adjust this if your path is different
customer_file = f'{base_path}customer.tbl'
orders_file = f'{base_path}orders.tbl'
lineitem_file = f'{base_path}lineitem.tbl'
supplier_file = f'{base_path}supplier.tbl'
part_file = f'{base_path}part.tbl'
partsupp_file = f'{base_path}partsupp.tbl'
nation_file = f'{base_path}nation.tbl'
region_file = f'{base_path}region.tbl'

# Function to check if files exist
def check_files_exist():
    files = [
        customer_file,
        orders_file,
        lineitem_file,
        supplier_file,
        part_file,
        partsupp_file,
        nation_file,
        region_file
    ]
    for file in files:
        if not os.path.exists(file):
            print(f"Error: {file} not found.")
            return False
    return True

# Function to load TPC-H data into DataFrames
def load_tpch_data():
    customer_df = pd.read_csv(customer_file, delimiter='|', header=None, names=['c_custkey', 'c_name', 'c_address', 'c_nationkey', 'c_phone', 'c_acctbal', 'c_mktsegment', 'c_comment'], usecols=range(8))
    orders_df = pd.read_csv(orders_file, delimiter='|', header=None, names=['o_orderkey', 'o_custkey', 'o_orderstatus', 'o_totalprice', 'o_orderdate', 'o_orderpriority', 'o_clerk', 'o_shippriority', 'o_comment'], usecols=range(9))
    lineitem_df = pd.read_csv(lineitem_file, delimiter='|', header=None, names=['l_orderkey', 'l_partkey', 'l_suppkey', 'l_linenumber', 'l_quantity', 'l_extendedprice', 'l_discount', 'l_tax', 'l_returnflag', 'l_linestatus', 'l_shipdate', 'l_commitdate', 'l_receiptdate', 'l_shipinstruct', 'l_shipmode', 'l_comment'], usecols=range(16))
    supplier_df = pd.read_csv(supplier_file, delimiter='|', header=None, names=['s_suppkey', 's_name', 's_address', 's_nationkey', 's_phone', 's_acctbal', 's_comment'], usecols=range(7))
    part_df = pd.read_csv(part_file, delimiter='|', header=None, names=['p_partkey', 'p_name', 'p_mfgr', 'p_brand', 'p_type', 'p_size', 'p_container', 'p_retailprice', 'p_comment'], usecols=range(9))
    partsupp_df = pd.read_csv(partsupp_file, delimiter='|', header=None, names=['ps_partkey', 'ps_suppkey', 'ps_availqty', 'ps_supplycost', 'ps_comment'], usecols=range(5))
    nation_df = pd.read_csv(nation_file, delimiter='|', header=None, names=['n_nationkey', 'n_name', 'n_regionkey', 'n_comment'], usecols=range(4))
    region_df = pd.read_csv(region_file, delimiter='|', header=None, names=['r_regionkey', 'r_name', 'r_comment'], usecols=range(3))
    return customer_df, orders_df, lineitem_df, supplier_df, part_df, partsupp_df, nation_df, region_df

# Function to store DataFrames in Redis
def store_data_in_redis(df, name):
    pipe = r.pipeline()
    for index, row in df.iterrows():
        pipe.hset(name, index, json.dumps(row.to_dict()))
    pipe.execute()

# Function to store DataFrames in B+Tree
def store_data_in_bptree(df, bptree):
    for index, row in df.iterrows():
        bptree.insert(str(index), json.dumps(row.to_dict()))

# Function to run a sample query and measure the time with Redis
def query_with_redis(query_num):
    # Measure total time including connection and data retrieval
    start_total_time = timeit.default_timer()
    
    # Start timing for data retrieval
    start_retrieval_time = timeit.default_timer()
    all_data = r.hgetall("lineitem")
    end_retrieval_time = timeit.default_timer()

    # Start timing for data processing
    start_processing_time = timeit.default_timer()
    result = [json.loads(item) for item in all_data.values() if int(json.loads(item)['l_quantity']) > 30]
    end_processing_time = timeit.default_timer()
    
    end_total_time = timeit.default_timer()

    retrieval_time_ms = (end_retrieval_time - start_retrieval_time) * 1000
    processing_time_ms = (end_processing_time - start_processing_time) * 1000
    total_time_ms = (end_total_time - start_total_time) * 1000

    print(f"Query {query_num} - Data Retrieval Time with Redis: {retrieval_time_ms:.2f} ms")
    print(f"Query {query_num} - Data Processing Time with Redis: {processing_time_ms:.2f} ms")
    print(f"Query {query_num} - Total Query Time with Redis: {total_time_ms:.2f} ms")

    return total_time_ms  # return total time in ms

# Function to run a sample query and measure the time with B+Tree
def query_with_bptree(query_num):
    # Measure total time including connection and data retrieval
    start_total_time = timeit.default_timer()

    # Start timing for data retrieval
    start_retrieval_time = timeit.default_timer()
    all_data = []
    for i in range(len(lineitem_df)):
        result = bptree.search(str(i))
        if result is not None:
            all_data.append(result)
    end_retrieval_time = timeit.default_timer()

    # Start timing for data processing
    start_processing_time = timeit.default_timer()
    result = [json.loads(item) for item in all_data if item and int(json.loads(item)['l_quantity']) > 30]
    end_processing_time = timeit.default_timer()
    
    end_total_time = timeit.default_timer()

    retrieval_time_ms = (end_retrieval_time - start_retrieval_time) * 1000
    processing_time_ms = (end_processing_time - start_processing_time) * 1000
    total_time_ms = (end_total_time - start_total_time) * 1000

    print(f"Query {query_num} - Data Retrieval Time with B+Tree: {retrieval_time_ms:.2f} ms")
    print(f"Query {query_num} - Data Processing Time with B+Tree: {processing_time_ms:.2f} ms")
    print(f"Query {query_num} - Total Query Time with B+Tree: {total_time_ms:.2f} ms")

    return total_time_ms  # return total time in ms

# Function to run a sample query and measure the time without Redis and B+Tree
def query_without_redis_and_bptree(df, query_num):
    start_time = timeit.default_timer()
    result = df[df['l_quantity'] > 30]
    end_time = timeit.default_timer()
    total_time_ms = (end_time - start_time) * 1000

    print(f"Query {query_num} - Total Query Time without Redis and B+Tree: {total_time_ms:.2f} ms")
    
    return total_time_ms  # return time in ms

# Main execution
# Reduce dataset size for testing
os.system(f"./dbgen -s 5 -f")

# Move files to the correct directory
os.system(f"mv -f *.tbl ./tpch-dbgen/")

# Check if the files exist
if not check_files_exist():
    print(f"Error: Some TPC-H files are missing for scale factor 5.")
    exit()

# Load data
customer_df, orders_df, lineitem_df, supplier_df, part_df, partsupp_df, nation_df, region_df = load_tpch_data()

query_times_with_redis = []
query_times_with_bptree = []
query_times_without_redis_and_bptree = []

# List of queries to run (randomly chosen queries from 1 to 20)
queries = [random.randint(1, 20) for _ in range(10)]  # Reduce number of queries for testing

for query_num, q in enumerate(queries, start=1):
    print(f"\nRunning Query {query_num}:")

    # Store data in B+Tree
    bptree = BPlusTree(max_degree=4)
    store_data_in_bptree(lineitem_df, bptree)
    time_with_bptree = query_with_bptree(query_num)
    query_times_with_bptree.append(time_with_bptree)

    # Store data in Redis
    store_data_in_redis(lineitem_df, "lineitem")

    # Measure query time with Redis
    time_with_redis = query_with_redis(query_num)
    query_times_with_redis.append(time_with_redis)

    # Measure query time without Redis and B+Tree
    time_without_redis_and_bptree = query_without_redis_and_bptree(lineitem_df, query_num)
    query_times_without_redis_and_bptree.append(time_without_redis_and_bptree)

print("\nFinal Results:")
print("Query Times with B+Tree:", query_times_with_bptree)
print("Query Times with Redis:", query_times_with_redis)
print("Query Times without Redis and B+Tree:", query_times_without_redis_and_bptree)
