import json
import os
import timeit
import zlib

import pandas as pd
import redis

# Setup Redis connection
redis_host = 'localhost'
redis_port = 6379
r = redis.Redis(host=redis_host, port=redis_port, db=0, decode_responses=False)

# Paths to TPC-H data files
base_path = './tpch-dbgen/'  # Adjust this if your path is different
customer_file = f'{base_path}customer.tbl'
orders_file = f'{base_path}orders.tbl'
lineitem_file = f'{base_path}lineitem.tbl'
supplier_file = f'{base_path}supplier.tbl'
part_file = f'{base_path}part.tbl'
partsupp_file = f'{base_path}partsupp.tbl'
nation_file = f'{base_path}nation.tbl'
region_file = f'{base_path}region.tbl'

# Function to check if files exist
def check_files_exist():
    files = [
        customer_file,
        orders_file,
        lineitem_file,
        supplier_file,
        part_file,
        partsupp_file,
        nation_file,
        region_file
    ]
    for file in files:
        if not os.path.exists(file):
            print(f"Error: {file} not found.")
            return False
    return True

# Function to load TPC-H data into DataFrames
def load_tpch_data():
    customer_df = pd.read_csv(customer_file, delimiter='|', header=None, names=['c_custkey', 'c_name', 'c_address', 'c_nationkey', 'c_phone', 'c_acctbal', 'c_mktsegment', 'c_comment'], usecols=range(8))
    orders_df = pd.read_csv(orders_file, delimiter='|', header=None, names=['o_orderkey', 'o_custkey', 'o_orderstatus', 'o_totalprice', 'o_orderdate', 'o_orderpriority', 'o_clerk', 'o_shippriority', 'o_comment'], usecols=range(9))
    lineitem_df = pd.read_csv(lineitem_file, delimiter='|', header=None, names=['l_orderkey', 'l_partkey', 'l_suppkey', 'l_linenumber', 'l_quantity', 'l_extendedprice', 'l_discount', 'l_tax', 'l_returnflag', 'l_linestatus', 'l_shipdate', 'l_commitdate', 'l_receiptdate', 'l_shipinstruct', 'l_shipmode', 'l_comment'], usecols=range(16))
    supplier_df = pd.read_csv(supplier_file, delimiter='|', header=None, names=['s_suppkey', 's_name', 's_address', 's_nationkey', 's_phone', 's_acctbal', 's_comment'], usecols=range(7))
    part_df = pd.read_csv(part_file, delimiter='|', header=None, names=['p_partkey', 'p_name', 'p_mfgr', 'p_brand', 'p_type', 'p_size', 'p_container', 'p_retailprice', 'p_comment'], usecols=range(9))
    partsupp_df = pd.read_csv(partsupp_file, delimiter='|', header=None, names=['ps_partkey', 'ps_suppkey', 'ps_availqty', 'ps_supplycost', 'ps_comment'], usecols=range(5))
    nation_df = pd.read_csv(nation_file, delimiter='|', header=None, names=['n_nationkey', 'n_name', 'n_regionkey', 'n_comment'], usecols=range(4))
    region_df = pd.read_csv(region_file, delimiter='|', header=None, names=['r_regionkey', 'r_name', 'r_comment'], usecols=range(3))
    return customer_df, orders_df, lineitem_df, supplier_df, part_df, partsupp_df, nation_df, region_df

# Function to compress data
def compress_data(data):
    return zlib.compress(json.dumps(data).encode('utf-8'))

# Function to decompress data
def decompress_data(data):
    return json.loads(zlib.decompress(data).decode('utf-8'))

# Function to store DataFrames in Redis
def store_data_in_redis(df, name):
    pipe = r.pipeline()
    for index, row in df.iterrows():
        pipe.hset(name, index, compress_data(row.to_dict()))
    pipe.execute()

# Function to run a sample query and measure the time with Redis
def query_with_redis(query_num):
    # Measure total time including connection and data retrieval
    start_total_time = timeit.default_timer()
    
    # Start timing for data retrieval
    start_retrieval_time = timeit.default_timer()
    all_data = r.hgetall("lineitem")
    end_retrieval_time = timeit.default_timer()

    # Start timing for data processing
    start_processing_time = timeit.default_timer()
    result = [decompress_data(item) for item in all_data.values() if int(decompress_data(item)['l_quantity']) > 30]
    end_processing_time = timeit.default_timer()
    
    end_total_time = timeit.default_timer()

    retrieval_time_ms = (end_retrieval_time - start_retrieval_time) * 1000
    processing_time_ms = (end_processing_time - start_processing_time) * 1000
    total_time_ms = (end_total_time - start_total_time) * 1000

    print(f"Query {query_num} - Data Retrieval Time with Redis: {retrieval_time_ms:.2f} ms")
    print(f"Query {query_num} - Data Processing Time with Redis: {processing_time_ms:.2f} ms")
    print(f"Query {query_num} - Total Query Time with Redis: {total_time_ms:.2f} ms")

    return total_time_ms  # return total time in ms

# Function to run a sample query and measure the time without Redis
def query_without_redis(df, query_num):
    start_time = timeit.default_timer()
    result = df[df['l_quantity'] > 30]
    end_time = timeit.default_timer()
    total_time_ms = (end_time - start_time) * 1000

    print(f"Query {query_num} - Total Query Time without Redis: {total_time_ms:.2f} ms")
    
    return total_time_ms  # return time in ms

# Main execution
# Clear Redis cache
r.flushall()

# Generate dataset using dbgen with scale factor 1 (1GB)
os.system(f"./dbgen -s 0.05 -f")

# Move files to the correct directory
os.system(f"mv -f *.tbl ./tpch-dbgen/")

# Check if the files exist
if not check_files_exist():
    print(f"Error: Some TPC-H files are missing for scale factor 1.")
    exit()

# Load data
customer_df, orders_df, lineitem_df, supplier_df, part_df, partsupp_df, nation_df, region_df = load_tpch_data()

query_times_with_redis = []
query_times_without_redis = []

# Number of queries to run (varying number of queries)
num_queries_list = [1, 5, 10, 50, 100, 500, 1000, 5000, 10000]

for num_queries in num_queries_list:
    print(f"\nRunning {num_queries} Queries:")

    # Measure query time with Redis
    store_data_in_redis(lineitem_df, "lineitem")
    total_time_with_redis = sum(query_with_redis(i+1) for i in range(num_queries))
    avg_time_with_redis = total_time_with_redis / num_queries
    query_times_with_redis.append(avg_time_with_redis)
    
    # Measure query time without Redis
    total_time_without_redis = sum(query_without_redis(lineitem_df, i+1) for i in range(num_queries))
    avg_time_without_redis = total_time_without_redis / num_queries
    query_times_without_redis.append(avg_time_without_redis)

print("\nFinal Results:")
print("Average Query Times with Redis (ms):", query_times_with_redis)
print("Average Query Times without Redis (ms):", query_times_without_redis)
