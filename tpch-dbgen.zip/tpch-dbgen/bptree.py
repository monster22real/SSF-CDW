class BPlusTree:
    def __init__(self, max_degree):
        self.root = BPlusTreeNode(max_degree)

    def insert(self, key, value):
        self.root.insert(key, value)

    def search(self, key):
        return self.root.search(key)

    def print_tree(self):
        self.root.print_node()

class BPlusTreeNode:
    def __init__(self, max_degree, is_leaf=True):
        self.keys = []
        self.values = []
        self.is_leaf = is_leaf
        self.children = []
        self.max_degree = max_degree

    def insert(self, key, value):
        if self.is_leaf:
            self.insert_leaf(key, value)
        else:
            index = self.find_child_index(key)
            self.children[index].insert(key, value)

    def insert_leaf(self, key, value):
        index = self.find_insert_index(key)
        self.keys.insert(index, key)
        self.values.insert(index, value)

        if len(self.keys) > self.max_degree - 1:
            self.split_leaf()

    def split_leaf(self):
        mid = len(self.keys) // 2
        right_node = BPlusTreeNode(self.max_degree, is_leaf=True)
        right_node.keys = self.keys[mid:]
        right_node.values = self.values[mid:]
        self.keys = self.keys[:mid]
        self.values = self.values[:mid]
        self.children.append(right_node)

    def find_child_index(self, key):
        for i, k in enumerate(self.keys):
            if key < k:
                return i
        return len(self.keys)

    def find_insert_index(self, key):
        for i, k in enumerate(self.keys):
            if key <= k:
                return i
        return len(self.keys)

    def search(self, key):
        if self.is_leaf:
            index = self.find_key_index(key)
            if index != -1:
                return self.values[index]
            return "Not found"
        else:
            index = self.find_child_index(key)
            if index < len(self.keys) and key == self.keys[index]:
                return self.children[index + 1].search(key)
            else:
                return self.children[index].search(key)

    def find_key_index(self, key):
        for i, k in enumerate(self.keys):
            if key == k:
                return i
        return -1

    def print_node(self, level=0):
        if level == 0:
            print("Root:", self.keys)
        else:
            print("Level", level, ":", self.keys)
        if not self.is_leaf:
            for child in self.children:
                child.print_node(level + 1)
