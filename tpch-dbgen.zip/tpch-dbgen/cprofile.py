import cProfile

cProfile.run('main()', 'output.prof')
